/*
 * SPDX-License-Identifier: MPL-2.0
 *
 * Copyright (C) 2014, PCA Peugeot Citroen, XS Embedded GmbH, TomTom
 * International B.V., Continental Automotive GmbH, BMW Car IT GmbH,
 * Alpine Electronics R&D Europe GmbH, AISIN AW CO., LTD.,  Neusoft
 * Technology Solutions GmbH, Jaguar Land Rover Limited,
 * Visteon Corporation, Elektrobit Automotive GmbH
 *
 * This Source Code Form is subject to the terms of the
 * Mozilla Public License, v. 2.0. If a copy of the MPL was not distributed with
 * this file, you can obtain one at http://mozilla.org/MPL/2.0/.
 */
// Generated from Franca IDL Interface
// using https://jinja.palletsprojects.com/en/2.10.x/
// 2022-03-07, 18:27:07

#include "audio.h"

// Constructors, etc.
audio::audio() { /* TODO, or use implicit */
}

audio::~audio() { /* TODO, or use implicit */
}

// functions for register
// Commands

void audio::register_command_serialize(const UInt16 &act,
                                       const UInt8 &majorClientVersion,
                                       const UInt8 &minorClientVersion,
                                       buffer &message_buffer) {
  /* Method body for register here */
  UInt8 fid = (UInt8)FID::FID_REGISTER;
  serializer container;
  container.push_back(fid);
  container.push_back(act);
  container.push_back(majorClientVersion);
  container.push_back(minorClientVersion);

  message_buffer = container.dump_container();
};

bool audio::register_command_deserialize(const buffer &message_buffer,
                                         UInt16 &act, UInt8 &majorClientVersion,
                                         UInt8 &minorClientVersion) {
  /* Method body for register here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)FID::FID_REGISTER) {
    return false;
  }
  act = container.pop_front(act);
  majorClientVersion = container.pop_front(majorClientVersion);
  minorClientVersion = container.pop_front(minorClientVersion);

  return true;
};

// Responses

void audio::register_response_serialize(const UInt16 &act,
                                        const UInt8 &majorServerVersion,
                                        const UInt8 &minorServerVersion,
                                        buffer &message_buffer) {
  /* Method body for register here */
  UInt8 fid = (UInt8)FID::FID_REGISTER + 1;
  serializer container;
  container.push_back(fid);
  container.push_back(act);
  container.push_back(majorServerVersion);
  container.push_back(minorServerVersion);

  message_buffer = container.dump_container();
};

bool audio::register_response_deserialize(const buffer &message_buffer,
                                          UInt16 &act,
                                          UInt8 &majorServerVersion,
                                          UInt8 &minorServerVersion) {
  /* Method body for register here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)(FID::FID_REGISTER) + 1) {
    return false;
  }
  act = container.pop_front(act);
  majorServerVersion = container.pop_front(majorServerVersion);
  minorServerVersion = container.pop_front(minorServerVersion);

  return true;
};

// functions for deregister
// Commands

void audio::deregister_command_serialize(const UInt16 &act,
                                         buffer &message_buffer) {
  /* Method body for deregister here */
  UInt8 fid = (UInt8)FID::FID_DEREGISTER;
  serializer container;
  container.push_back(fid);
  container.push_back(act);

  message_buffer = container.dump_container();
};

bool audio::deregister_command_deserialize(const buffer &message_buffer,
                                           UInt16 &act) {
  /* Method body for deregister here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)FID::FID_DEREGISTER) {
    return false;
  }
  act = container.pop_front(act);

  return true;
};

// Responses

void audio::deregister_response_serialize(const UInt16 &act,
                                          buffer &message_buffer) {
  /* Method body for deregister here */
  UInt8 fid = (UInt8)FID::FID_DEREGISTER + 1;
  serializer container;
  container.push_back(fid);
  container.push_back(act);

  message_buffer = container.dump_container();
};

bool audio::deregister_response_deserialize(const buffer &message_buffer,
                                            UInt16 &act) {
  /* Method body for deregister here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)(FID::FID_DEREGISTER) + 1) {
    return false;
  }
  act = container.pop_front(act);

  return true;
};

// functions for setStreamState
// Commands

void audio::setStreamState_command_serialize(const UInt16 &act,
                                             const StreamId &id,
                                             const Operation &op,
                                             buffer &message_buffer) {
  /* Method body for setStreamState here */
  UInt8 fid = (UInt8)FID::FID_SETSTREAMSTATE;
  serializer container;
  container.push_back(fid);
  container.push_back(act);
  container.push_back(id);
  container.push_back(op);

  message_buffer = container.dump_container();
};

bool audio::setStreamState_command_deserialize(const buffer &message_buffer,
                                               UInt16 &act, StreamId &id,
                                               Operation &op) {
  /* Method body for setStreamState here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)FID::FID_SETSTREAMSTATE) {
    return false;
  }
  act = container.pop_front(act);
  id = container.pop_front(id);
  op = container.pop_front(op);

  return true;
};

// Responses

void audio::setStreamState_response_serialize(const UInt16 &act,
                                              buffer &message_buffer) {
  /* Method body for setStreamState here */
  UInt8 fid = (UInt8)FID::FID_SETSTREAMSTATE + 1;
  serializer container;
  container.push_back(fid);
  container.push_back(act);

  message_buffer = container.dump_container();
};

bool audio::setStreamState_response_deserialize(const buffer &message_buffer,
                                                UInt16 &act) {
  /* Method body for setStreamState here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)(FID::FID_SETSTREAMSTATE) + 1) {
    return false;
  }
  act = container.pop_front(act);

  return true;
};

// functions for getStreamState
// Commands

void audio::getStreamState_command_serialize(const UInt16 &act,
                                             const StreamId &id,
                                             buffer &message_buffer) {
  /* Method body for getStreamState here */
  UInt8 fid = (UInt8)FID::FID_GETSTREAMSTATE;
  serializer container;
  container.push_back(fid);
  container.push_back(act);
  container.push_back(id);

  message_buffer = container.dump_container();
};

bool audio::getStreamState_command_deserialize(const buffer &message_buffer,
                                               UInt16 &act, StreamId &id) {
  /* Method body for getStreamState here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)FID::FID_GETSTREAMSTATE) {
    return false;
  }
  act = container.pop_front(act);
  id = container.pop_front(id);

  return true;
};

// Responses

void audio::getStreamState_response_serialize(const UInt16 &act,
                                              const State &st,
                                              buffer &message_buffer) {
  /* Method body for getStreamState here */
  UInt8 fid = (UInt8)FID::FID_GETSTREAMSTATE + 1;
  serializer container;
  container.push_back(fid);
  container.push_back(act);
  container.push_back(st);

  message_buffer = container.dump_container();
};

bool audio::getStreamState_response_deserialize(const buffer &message_buffer,
                                                UInt16 &act, State &st) {
  /* Method body for getStreamState here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)(FID::FID_GETSTREAMSTATE) + 1) {
    return false;
  }
  act = container.pop_front(act);
  st = container.pop_front(st);

  return true;
};

// functions for getListOfStreams
// Commands

void audio::getListOfStreams_command_serialize(const UInt16 &act,
                                               buffer &message_buffer) {
  /* Method body for getListOfStreams here */
  UInt8 fid = (UInt8)FID::FID_GETLISTOFSTREAMS;
  serializer container;
  container.push_back(fid);
  container.push_back(act);

  message_buffer = container.dump_container();
};

bool audio::getListOfStreams_command_deserialize(const buffer &message_buffer,
                                                 UInt16 &act) {
  /* Method body for getListOfStreams here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)FID::FID_GETLISTOFSTREAMS) {
    return false;
  }
  act = container.pop_front(act);

  return true;
};

// Responses

void audio::getListOfStreams_response_serialize(const UInt16 &act,
                                                const std::vector<Stream> &list,
                                                buffer &message_buffer) {
  /* Method body for getListOfStreams here */
  UInt8 fid = (UInt8)FID::FID_GETLISTOFSTREAMS + 1;
  serializer container;
  container.push_back(fid);
  container.push_back(act);
  container.push_back(list);

  message_buffer = container.dump_container();
};

bool audio::getListOfStreams_response_deserialize(const buffer &message_buffer,
                                                  UInt16 &act,
                                                  std::vector<Stream> &list) {
  /* Method body for getListOfStreams here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)(FID::FID_GETLISTOFSTREAMS) + 1) {
    return false;
  }
  act = container.pop_front(act);
  list = container.pop_front(list);

  return true;
};

// functions for setEventField
// Commands

void audio::setEventField_command_serialize(const UInt16 &act,
                                            const StreamId &id,
                                            const EventField &field,
                                            buffer &message_buffer) {
  /* Method body for setEventField here */
  UInt8 fid = (UInt8)FID::FID_SETEVENTFIELD;
  serializer container;
  container.push_back(fid);
  container.push_back(act);
  container.push_back(id);
  container.push_back(field);

  message_buffer = container.dump_container();
};

bool audio::setEventField_command_deserialize(const buffer &message_buffer,
                                              UInt16 &act, StreamId &id,
                                              EventField &field) {
  /* Method body for setEventField here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)FID::FID_SETEVENTFIELD) {
    return false;
  }
  act = container.pop_front(act);
  id = container.pop_front(id);
  field = container.pop_front(field);

  return true;
};

// Responses

void audio::setEventField_response_serialize(const UInt16 &act,
                                             buffer &message_buffer) {
  /* Method body for setEventField here */
  UInt8 fid = (UInt8)FID::FID_SETEVENTFIELD + 1;
  serializer container;
  container.push_back(fid);
  container.push_back(act);

  message_buffer = container.dump_container();
};

bool audio::setEventField_response_deserialize(const buffer &message_buffer,
                                               UInt16 &act) {
  /* Method body for setEventField here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)(FID::FID_SETEVENTFIELD) + 1) {
    return false;
  }
  act = container.pop_front(act);

  return true;
};

// functions for getEventField
// Commands

void audio::getEventField_command_serialize(const UInt16 &act,
                                            const StreamId &id,
                                            buffer &message_buffer) {
  /* Method body for getEventField here */
  UInt8 fid = (UInt8)FID::FID_GETEVENTFIELD;
  serializer container;
  container.push_back(fid);
  container.push_back(act);
  container.push_back(id);

  message_buffer = container.dump_container();
};

bool audio::getEventField_command_deserialize(const buffer &message_buffer,
                                              UInt16 &act, StreamId &id) {
  /* Method body for getEventField here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)FID::FID_GETEVENTFIELD) {
    return false;
  }
  act = container.pop_front(act);
  id = container.pop_front(id);

  return true;
};

// Responses

void audio::getEventField_response_serialize(const UInt16 &act,
                                             const EventField &field,
                                             buffer &message_buffer) {
  /* Method body for getEventField here */
  UInt8 fid = (UInt8)FID::FID_GETEVENTFIELD + 1;
  serializer container;
  container.push_back(fid);
  container.push_back(act);
  container.push_back(field);

  message_buffer = container.dump_container();
};

bool audio::getEventField_response_deserialize(const buffer &message_buffer,
                                               UInt16 &act, EventField &field) {
  /* Method body for getEventField here */
  UInt8 fid = 0;
  serializer container(message_buffer);
  fid = container.pop_front(fid);
  if (fid != (UInt8)(FID::FID_GETEVENTFIELD) + 1) {
    return false;
  }
  act = container.pop_front(act);
  field = container.pop_front(field);

  return true;
};
