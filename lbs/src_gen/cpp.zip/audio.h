/*
 * SPDX-License-Identifier: MPL-2.0
 *
 * Copyright (C) 2014, PCA Peugeot Citroen, XS Embedded GmbH, TomTom
 * International B.V., Continental Automotive GmbH, BMW Car IT GmbH,
 * Alpine Electronics R&D Europe GmbH, AISIN AW CO., LTD.,  Neusoft
 * Technology Solutions GmbH, Jaguar Land Rover Limited,
 * Visteon Corporation, Elektrobit Automotive GmbH
 *
 * This Source Code Form is subject to the terms of the
 * Mozilla Public License, v. 2.0. If a copy of the MPL was not distributed with
 * this file, you can obtain one at http://mozilla.org/MPL/2.0/.
 */
#pragma once
// Generated from Franca IDL Interface
// 2022-03-07, 18:27:07

#include "audio.types.h"
#include "serializer.h"

class audio {
public:
  audio();
  ~audio();

  // functions for register
  // Commands

  void register_command_serialize(const UInt16 &act,
                                  const UInt8 &majorClientVersion,
                                  const UInt8 &minorClientVersion,
                                  buffer &message_buffer);

  bool register_command_deserialize(const buffer &message_buffer, UInt16 &act,
                                    UInt8 &majorClientVersion,
                                    UInt8 &minorClientVersion);

  // Responses

  void register_response_serialize(const UInt16 &act,
                                   const UInt8 &majorServerVersion,
                                   const UInt8 &minorServerVersion,
                                   buffer &message_buffer);

  bool register_response_deserialize(const buffer &message_buffer, UInt16 &act,
                                     UInt8 &majorServerVersion,
                                     UInt8 &minorServerVersion);

  // functions for deregister
  // Commands

  void deregister_command_serialize(const UInt16 &act, buffer &message_buffer);

  bool deregister_command_deserialize(const buffer &message_buffer,
                                      UInt16 &act);

  // Responses

  void deregister_response_serialize(const UInt16 &act, buffer &message_buffer);

  bool deregister_response_deserialize(const buffer &message_buffer,
                                       UInt16 &act);

  // functions for setStreamState
  // Commands

  void setStreamState_command_serialize(const UInt16 &act, const StreamId &id,
                                        const Operation &op,
                                        buffer &message_buffer);

  bool setStreamState_command_deserialize(const buffer &message_buffer,
                                          UInt16 &act, StreamId &id,
                                          Operation &op);

  // Responses

  void setStreamState_response_serialize(const UInt16 &act,
                                         buffer &message_buffer);

  bool setStreamState_response_deserialize(const buffer &message_buffer,
                                           UInt16 &act);

  // functions for getStreamState
  // Commands

  void getStreamState_command_serialize(const UInt16 &act, const StreamId &id,
                                        buffer &message_buffer);

  bool getStreamState_command_deserialize(const buffer &message_buffer,
                                          UInt16 &act, StreamId &id);

  // Responses

  void getStreamState_response_serialize(const UInt16 &act, const State &st,
                                         buffer &message_buffer);

  bool getStreamState_response_deserialize(const buffer &message_buffer,
                                           UInt16 &act, State &st);

  // functions for getListOfStreams
  // Commands

  void getListOfStreams_command_serialize(const UInt16 &act,
                                          buffer &message_buffer);

  bool getListOfStreams_command_deserialize(const buffer &message_buffer,
                                            UInt16 &act);

  // Responses

  void getListOfStreams_response_serialize(const UInt16 &act,
                                           const std::vector<Stream> &list,
                                           buffer &message_buffer);

  bool getListOfStreams_response_deserialize(const buffer &message_buffer,
                                             UInt16 &act,
                                             std::vector<Stream> &list);

  // functions for setEventField
  // Commands

  void setEventField_command_serialize(const UInt16 &act, const StreamId &id,
                                       const EventField &field,
                                       buffer &message_buffer);

  bool setEventField_command_deserialize(const buffer &message_buffer,
                                         UInt16 &act, StreamId &id,
                                         EventField &field);

  // Responses

  void setEventField_response_serialize(const UInt16 &act,
                                        buffer &message_buffer);

  bool setEventField_response_deserialize(const buffer &message_buffer,
                                          UInt16 &act);

  // functions for getEventField
  // Commands

  void getEventField_command_serialize(const UInt16 &act, const StreamId &id,
                                       buffer &message_buffer);

  bool getEventField_command_deserialize(const buffer &message_buffer,
                                         UInt16 &act, StreamId &id);

  // Responses

  void getEventField_response_serialize(const UInt16 &act,
                                        const EventField &field,
                                        buffer &message_buffer);

  bool getEventField_response_deserialize(const buffer &message_buffer,
                                          UInt16 &act, EventField &field);

private:
  // none
};