#pragma once
// Generated from Franca IDL Interface
// 2022-03-07, 18:27:07

/*
 * SPDX-License-Identifier: MPL-2.0
 *
 * Copyright (C) 2014, PCA Peugeot Citroen, XS Embedded GmbH, TomTom
 * International B.V., Continental Automotive GmbH, BMW Car IT GmbH,
 * Alpine Electronics R&D Europe GmbH, AISIN AW CO., LTD.,  Neusoft
 * Technology Solutions GmbH, Jaguar Land Rover Limited,
 * Visteon Corporation, Elektrobit Automotive GmbH
 *
 * This Source Code Form is subject to the terms of the
 * Mozilla Public License, v. 2.0. If a copy of the MPL was not distributed with
 * this file, you can obtain one at http://mozilla.org/MPL/2.0/.
 */

#include "franca_types.h"

// Typedef #0 from audio in package org.bosch.xc.civic.avb_c.audio
enum class State {
  ST_PLAYING,
  ST_STOPPED,
  ST_FAILURE,

};

// Typedef #1 from audio in package org.bosch.xc.civic.avb_c.audio
enum class FID {
  FID_REGISTER = 32,
  FID_DEREGISTER = 34,
  FID_SETSTREAMSTATE = 48,
  FID_GETSTREAMSTATE = 50,
  FID_GETLISTOFSTREAMS = 52,
  FID_SETEVENTFIELD = 54,
  FID_GETEVENTFIELD = 56,
  FID_ERROROCCURED = 37,
  FID_COMMANDERROROCCURED = 39,

};

// Typedef #2 from audio in package org.bosch.xc.civic.avb_c.audio
enum class GenericErrors {
  FAILURE_GENERIC_ERROR,
  FAILURE_UNKOWN_STREAM_ID,

};

// Typedef #3 from audio in package org.bosch.xc.civic.avb_c.audio
enum class BroadcastErrors {
  FAILURE_CRF_STREAM_NOT_AVAILABLE,

};

// Typedef #4 from audio in package org.bosch.xc.civic.avb_c.audio
enum class GenericCommandErrors {
  ERR_NO_ERROR,
  ERR_VERSION_MISMATCH,
  ERR_UNKNOWN_FID,
  ERR_UNKNOWN_PARAMETER,
  ERR_UNDEFINED_PAYLOAD,
  ERR_SEQUENCE_ERROR,

};

// Typedef #5 from audio in package org.bosch.xc.civic.avb_c.audio
enum class Operation {
  OP_START,
  OP_STOP,

};

// Typedef #6 from audio in package org.bosch.xc.civic.avb_c.audio
enum class StreamId {
  CIVIC_ENTERTAINMENT_STREAM = 8,
  CIVIC_INFOTAINMENT_STREAM = 9,
  CIVIC_IC_STREAM = 10,
  CIVIC_LOWLATENCY_STREAM = 11,

};

// Typedef #7 from audio in package org.bosch.xc.civic.avb_c.audio
enum class EventField {
  EF_STATIC = 0,
  EF_STEREO = 2,
  EF_MULTICHANNEL_5_1 = 3,
  EF_MULTICHANNEL_7_1 = 4,
  EF_MULTICHANNEL_7_1_4 = 5,

};

// Typedef #8 from audio in package org.bosch.xc.civic.avb_c.audio
struct Stream {
  StreamId id;
  State st;
};
